from django.db import models

# Create your models here.


class Cliente(models.Model):
    nombre = models.CharField(max_length=200)
    apellido = models.CharField(max_length=200)
    email = models.EmailField()
    nacimiento = models.DateField()

    def __str__(self) -> str:
        return f"{self.apellido.upper()}, {self.nombre}"
